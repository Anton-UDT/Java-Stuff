package sortingPackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class NameSorterTest {
//=========================================================================================================>
	@Test //Test to see that its getting data
	public void recievesNames() {
		String[] nameArray = {"Bob", "Kay", "Sam"}; // sets nameArray strings
		NameSorter names = new NameSorter(nameArray); //creates a variable names with the contents from nameArray
		assertArrayEquals(names.getSortedArray(), nameArray); // checks the array if it is the same as nameAarray
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Kay", "Sam" into alphabetical order
	public void sortNames() {
		String[] nameArray = {"Bob", "Kay", "Sam"}; // sets nameArray strings
		String[] sortedArray = {"Bob", "Kay", "Sam"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Bob", "Bob" into alphabetical order
	public void sortSameName() {
		String[] nameArray = {"Bob", "Bob", "Bob"}; // sets nameArray strings
		String[] sortedArray = {"Bob", "Bob", "Bob"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortNotSortedNames() {
		String[] nameArray = {"Jim", "Bob", "Sue"}; // sets nameArray strings
		String[] sortedArray = {"Bob", "Jim", "Sue"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortUnSortedNames() {
		String[] nameArray = {"Tim", "Ann", "Tom"}; // sets nameArray strings
		String[] sortedArray = {"Ann", "Tim", "Tom"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortSomeUnSortedNames() {
		String[] nameArray = {"Tom", "Ann", "Tim"}; // sets nameArray strings
		String[] sortedArray = {"Ann", "Tim", "Tom"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortMoreUnSortedNames() {
		String[] nameArray = {"Tom", "Tim", "Tam"}; // sets nameArray strings
		String[] sortedArray = {"Tam", "Tim", "Tom"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortEvenMoreUnSortedNames() {
		String[] nameArray = {"Sue", "Susan", "Suesan"}; // sets nameArray strings
		String[] sortedArray = {"Sue", "Suesan", "Susan"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortThyUnSortedNames() {
		String[] nameArray = {"Jamie", "James", "Jimmy"}; // sets nameArray strings
		String[] sortedArray = {"James", "Jamie", "Jimmy"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
	@Test //Sorts the names "Bob", "Jim", "Sue" into alphabetical order
	public void sortLotsOFUnSortedNames() {
		String[] nameArray = {"Jamie", "James", "Jimmy", "Tim", "Tom", "Bob", "Sue", "Susan", "Suesan"}; // sets nameArray strings
		String[] sortedArray = {"Bob", "James", "Jamie", "Jimmy", "Sue", "Suesan", "Susan", "Tim", "Tom"}; // sets what it should look like after sort
		NameSorter names = new NameSorter(nameArray);
		assertArrayEquals(names.getSortedArray(), sortedArray);
	}
//=========================================================================================================>
}
