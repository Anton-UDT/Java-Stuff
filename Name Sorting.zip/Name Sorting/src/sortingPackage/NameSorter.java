package sortingPackage;
import java.util.*;

public class NameSorter {
	String[] nameArray; //Setting up the array
	
	public NameSorter(String[] inputArray) {
		//every time there`s a new nameArray it will get the sorted contents from the sorterArray
		nameArray = sorterArray(inputArray);
	}
	public String[] sorterArray(String[] inputArray) {
		// Names sorting code...
		Arrays.sort(inputArray);
		return inputArray;
	}
	public String[] getSortedArray() {
		return nameArray;
	}
}
