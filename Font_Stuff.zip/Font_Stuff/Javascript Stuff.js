
                                // These make the text bold and italic \\

  var app = angular.module('angularRoot', []);

  app.controller('displayContents',  function($scope) {
 $scope.dupeDiv = "test";
    console.log($scope.dupeDiv)

  });

$(document).ready(function() {
  $('#boldTextButton').click(function() {
    console.log("bold");
    document.execCommand('bold');
  });
});

$(document).ready(function() {
    $('#italicTextButton').click(function() {
    console.log("italic");
    document.execCommand('italic');
    });
});


/*==============================================================================================*/
                                // These change the font size \\

/* A number from 1 to 7 that defines the size of the text. Browser default is 3 */

function changeFont1() {
console.log("large text");
    document.execCommand("fontSize", false, "6");
    var fontElements = document.getElementsByTagName("font");
    for (var i = 0, len = fontElements.length; i < len; ++i) {
        if (fontElements[i].size == "6") {
            fontElements[i].removeAttribute("size");
            fontElements[i].style.fontSize = "1.2rem";
        }
    }
}

function changeFont2() {
console.log("normal text");
    document.execCommand("fontSize", false, "5");
    var fontElements = document.getElementsByTagName("font");
    for (var i = 0, len = fontElements.length; i < len; ++i) {
        if (fontElements[i].size == "5") {
            fontElements[i].removeAttribute("size");
            fontElements[i].style.fontSize = "1rem";
        }
    }
}

function changeFont3() {
console.log("small text");
    document.execCommand("fontSize", false, "2");

    var fontElements = document.getElementsByTagName("font");
    for (var i = 0, len = fontElements.length; i < len; ++i) {
        if (fontElements[i].size == "2") {
            fontElements[i].removeAttribute("size");
            fontElements[i].style.fontSize = "0.8rem";
        }
    }
}

/*==============================================================================================*/
                                 // This is for the submit button \\
var message312 = "editableClass";

function alertBox1() {
    window.alert(message312);
}

/*==============================================================================================*/
                                // This is for the facebook plugin \\

/*(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));







/*==============================================================================================*/
                                  // This is angular stuff \\



/* you are searching to use the angular.element and document.getElementById stuff*/




