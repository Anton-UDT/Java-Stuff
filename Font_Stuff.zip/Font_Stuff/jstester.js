
var app = angular.module('TextAngularDemo', ['textAngular'])


app.config(['$provide', function($provide){
		// this demonstrates how to register a new tool and add it to the default toolbar
		$provide.decorator('taOptions', ['taRegisterTool', 'taSelection', 'taBrowserTag', 'taTranslations',
                                             'taToolFunctions', '$delegate',
                                             function(taRegisterTool, taSelection, taBrowserTag, taTranslations,
                                                      taToolFunctions, taOptions){



			// $delegate is the taOptions we are decorating
			// here we override the default toolbars and classes specified in taOptions.
			taOptions.forceTextAngularSanitize = true; // set false to allow the textAngular-sanitize provider to be replaced
			taOptions.keyMappings = []; // allow customizable keyMappings for specialized key boards or languages
			taOptions.toolbar = [
			    ['fontSizeSmall', 'fontSizeNormal', 'fontSizeLarge'],
				['bold', 'italics', 'insertLink']
			];
			taOptions.classes = {
				focussed: 'focussed',
				toolbar: 'btn-toolbar',
				toolbarGroup: 'btn-group',
				toolbarButton: 'btn btn-default',
				toolbarButtonActive: 'active',
				disabled: 'disabled',
				textEditor: 'form-control',
				htmlEditor: 'form-control'
			};
			return taOptions; // whatever you return will be the taOptions
		}])


	}]);


app.config(function($provide){
	$provide.decorator('taOptions', ['taRegisterTool', '$delegate', function(taRegisterTool, taOptions){
		// $delegate is the taOptions we are decorating
		// register the tool with textAngular
		taRegisterTool('fontSizeLarge', {
			buttontext: "Large Text",
			action: function(){
				this.$editor().wrapSelection('fontSize', '2rem');
			}
		});
		taRegisterTool('fontSizeNormal', {
		buttontext: "Normal Text",
		action: function(){
		this.$editor().wrapSelection('fontSize', '1rem');
		}
		});
		taRegisterTool('fontSizeSmall', {
		buttontext: "Small Text",
		action: function(){
		this.$editor().wrapSelection('fontSize', '0.9rem');
		}
		});
		return taOptions;
	}]);
});




app.controller("DemoTextEditorCtrl", function($scope) {



});