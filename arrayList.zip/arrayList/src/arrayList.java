import java.lang.*;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by Anthony Funai on 25/03/2017.
 */
public class arrayList {

                                    /* Global Variables */





/* ================================================================================================================= */

                                    /* Constructors/main */

    public static ArrayList<String> listStufff = new ArrayList<String>();

    public static void main(String[] args){





        /* This adds stuff to the list, in this case 'five' 'ten' 'fifteen' and so on */
            listStufff.add("Five");
            listStufff.add("Ten");
            listStufff.add("Fifteen");
            listStufff.add("Twenty");
            listStufff.add("Twenty-five");
            listStufff.add("Thirty");
            listStufff.add("Thirty-five");
            listStufff.add("forty");



       /* These are the local variables - the first one gets the first item in the array list and finds the length of it */
            int largestString = listStufff.get(0).length();
            int index = 0;
            int index2 = 0;


        /* This is the code that finds the longest object in the list and stores it */
            for(int i = 0; i < listStufff.size(); i++)
            {
                if(listStufff.get(i).length() > largestString)
                {
                    largestString = listStufff.get(i).length();
                    index = i;
                }
            }
            /* This is the code that finds the smallest object in the list and stores it */
            for(int i = 0; i < listStufff.size(); i++)
            {
                if(listStufff.get(i).length() < largestString)
                {
                    largestString = listStufff.get(i).length();
                    index2 = i;
                }
            }


            /* This makes the strings in the list display on a new line instead of next to each other */
            for(String stuffList : listStufff){



            /* This displays the objects in the list */
                System.out.println(stuffList);
            }

                 /* These display the longest and smallest objects in the list */
            System.out.println("\nThe longest in the list is: "+ listStufff.get(index));
            System.out.println("\nThe smallest in the list is: "+ listStufff.get(index2));
            System.out.println("\nThe words that contain 'py' are: " + listStufff.stream().filter((s -> s.contains("ty"))).collect(Collectors.toList()) );
            System.out.println("\nThe words that contain 't' are: " + listStufff.stream().filter((s -> s.contains("t"))).collect(Collectors.toList()) );
            System.out.println("\nThe words that contain '-' are: " + listStufff.stream().filter((s -> s.contains("-"))).collect(Collectors.toList()) );


        }










/* ================================================================================================================= */


                                    /* Getters & Setters */









}
